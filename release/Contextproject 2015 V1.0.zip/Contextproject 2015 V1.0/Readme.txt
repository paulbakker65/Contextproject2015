Version 1.0
Contextproject 2015 
Health informatics group 5/e

To start the program simply double click 'Contextproject2015.jar'. 
Please make sure you have Java runtime installed. If not it can be downloaded from http://www.oracle.com/technetwork/java/javase/downloads/index.html

To run example_scripts or example_cli you need to copy the folder 'medical', containing all the Admire data files, to the root directory.